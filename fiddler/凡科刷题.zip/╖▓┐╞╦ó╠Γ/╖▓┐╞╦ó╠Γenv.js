const $ = new Env('凡科刷题');
var index=0;
	var score_Qt={};
	var ans=[],ansa={};
	var url="https://11671843-121.hd.faisco.cn/api/game4Qt/qtGame_Req?aid=11671843&_openId=oosnVwsXAEXIsYsYavSIh8dm2ORU";
	
	//var data="questionObj=%7B%22gameId%22%3A7%2C%22req_Type%22%3A%22get%22%2C%22isManage%22%3Afalse%2C%22qtInfoParam%22%3A%7B%22exposure_QtList%22%3A%5B%5D%2C%22score_Qt%22%3A%7B%7D%2C%22qtNum%22%3A10%2C%22qtScore%22%3A10%7D%2C%22openId%22%3A%22oosnVwrzV57UVm61s4BEkd6ERRgg%22%7D&canal=-1&playerOrigin=3&uid="
	var cookie="_cliid=c5IDnGRA51nQeZY0; scope=snsapi_userinfo; oid_15722577_32=oosnVwsXAEXIsYsYavSIh8dm2ORU; visitorA=0.2970811404353939; oid_11671843_121=oosnVwsXAEXIsYsYavSIh8dm2ORU; oid_26733849_6=oosnVwsXAEXIsYsYavSIh8dm2ORU; _AID=11671843; faiOpenId=oosnVwsXAEXIsYsYavSIh8dm2ORU; hdOpenIdSign_11671843=2892bb2ca421a3c5b45157a7cde4f701; gps_province=; gps_city=; gps_district=";
	var gameId=121;
	var openid="oosnVwsXAEXIsYsYavSIh8dm2ORU";
	var qtNum=10;
	var qtScore=10;
	var exposure_QtList=[];
	var r_List=[];
	var allAnswerList=[];
	var titleIndex;
	var index1=1;
	var currentAns;
!(async() => {
	
	for(var i=0;i<50;i++){
		await firstget();
		await check(currentAns.data.titleIndex,currentAns.data.allAnswerList[0])
	}
	
	var fs=require('fs');
	var now=date("Y-m-d_H:i:s")
		 /* var fd=fs.openSync('fanke.txt','w');
		  for(var i=0;i<ans.length;i++){
			 fs.appendFileSync('fanke.txt',ans[i]+'\r\n');
		  }*/
		  console.log(ansa)
	//var fd=fs.openSync('fanke_'+now+'.txt','w');
		fs.appendFileSync('fanke_1.txt',JSON.stringify(ansa)+'\r\n');


})().catch((e) => {
    $.log('', `❌ ${$.name}, 失败! 原因: ${e}!`, '')
  })
  .finally(() => {
    $.done();
  });

  function firstget() {
  return new Promise(async resolve => {
	var request = require("request");
	 exposure_QtList=[];
	score_Qt={}
	//{"gameId":10,"req_Type":"get","isManage":false,"titleIndex":null,"playerAnswer":null,"qtInfoParam":{"exposure_QtList":[],"score_Qt":{},"qtNum":10,"qtScore":10},"openId":"oosnVwpUtn1ZPcIldZovuzjPxnRI"}
	var questionObj={"gameId":gameId,"req_Type":"get","isManage":false,"qtInfoParam":{"exposure_QtList":exposure_QtList,"score_Qt":score_Qt,"qtNum":qtNum,"qtScore":qtScore},"openId":openid};
	var data1="questionObj="+JSON.stringify(questionObj)+"&canal=-1&playerOrigin=3&uid=";
	//console.log(data1)
    const options = {
      "url": url,
      "headers": {
        'Host': '25938733-5.hd.faisco.cn',
		'Connection': 'keep-alive',
		'Origin': 'https://18062026-14.hd.faisco.cn',
			'X-Requested-With': 'XMLHttpRequest',
			'Accept-Charset':"utf-8",
		'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
		'Referer': 'https://25938733-5.hd.faisco.cn/25938733/T-WXnewebaUBnvIuAdqLyw/nldtz.html?_source=1&appid=wx50775cad5d08d7ad',
		'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Mobile/14F89 MicroMessenger/7.0.17(0x1700112a) NetType/WIFI Language/zh_CN',
		'Accept':'*/*',
		'Accept-Language': 'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
		'Cookie':cookie,
		//'Content-Length': data1.length
		
      },
	  'body':data1
    }
	//console.log(options);
	request.post(options, function(err, resp, data) {
        try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            data = JSON.parse(data);
			
			console.log(data);

			var title=data.data.title+(data.data.moreAnswer?" 多选":"单选");

			 ans.push(data.data.titleIndex+">>>")
				
			ans.push(title);
			for(var i=0;i<data.data.allAnswerList.length;i++){
				//console.log(data.data.allAnswerList[i].answer)
				ans.push(data.data.allAnswerList[i].answer);
			}
			currentAns=data
          } else {
            console.log(`服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve(data);
      }
    })
  })
}

function check(titleIndex,an){
	allAnswerList=[{"answer":an.answer,"sign":an.sign}];
	exposure_QtList.push(titleIndex);
	//var questionObj={"gameId":gameId,"req_Type":"check","isManage":false,"playerAnswer":an.answer,"qtInfoParam":{"exposure_QtList":exposure_QtList,"score_Qt":score_Qt,"qtNum":qtNum,"qtScore":qtNum,"moreAnswer":false,"allAnswerList":[{"answer":an.answer,"sign":an.sign}]},"openId":openid};
	
	var questionObj={"gameId":gameId,"req_Type":"check","isManage":false,"playerAnswer":an.answe,"qtInfoParam":{"exposure_QtList":exposure_QtList,"score_Qt":score_Qt,"qtNum":qtNum,"qtScore":qtScore,"moreAnswer":false,"allAnswerList":[{"answer":an.answer,"sign":an.sign}]},"openId":openid}

	var data1="questionObj="+JSON.stringify(questionObj)+"&canal=-1&playerOrigin=3&uid=";
	console.log(data1)
	return new Promise(async resolve => {
			var request = require("request");
			const options = {
			  "url": url,
			  "headers": {
				'Host': '25938733-5.hd.faisco.cn',
				'Connection': 'keep-alive',
				'Origin': 'https://18062026-14.hd.faisco.cn',
					'X-Requested-With': 'XMLHttpRequest',
					'Accept-Charset':"utf-8",
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'Referer': 'https://25938733-5.hd.faisco.cn/25938733/T-WXnewebaUBnvIuAdqLyw/nldtz.html?_source=1&appid=wx50775cad5d08d7ad',
				'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Mobile/14F89 MicroMessenger/7.0.17(0x1700112a) NetType/WIFI Language/zh_CN',
				'Accept':'*/*',
				'Accept-Language': 'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
				'Cookie':cookie,
				//'Content-Length': data1.length
				
			  },
			  'body':data1
			}
			//console.log(options);
			request.post(options, function(err, resp, data) {
				try {
				if (err) {
				  console.log(`${JSON.stringify(err)}`)
				  console.log(`${$.name} API请求失败，请检查网路重试`)
				} else {
				  if (data) {
					data = JSON.parse(data);
					
					var right=[];
					console.log(data)
					//	console.log('------------')
						if(data.success==false) {
							//firstget();
							//return;
							
						}
					score_Qt=data.data.score_Qt;
					r_List=data.data.r_List;
					for(var i=0;i<data.data.r_List.length;i++){
						right.push(data.data.r_List[i].answer)
					}
					ansa[titleIndex+""]=right.join(",")
					console.log(ansa)
				  } else {
					
				  }
				}
			  } catch (e) {
				$.logErr(e, resp)
			  } finally {
				resolve();
			  }
			})
		  })
}
// prettier-ignore
function Env(t,e){class s{constructor(t){this.env=t}send(t,e="GET"){t="string"==typeof t?{url:t}:t;let s=this.get;return"POST"===e&&(s=this.post),new Promise((e,i)=>{s.call(this,t,(t,s,r)=>{t?i(t):e(s)})})}get(t){return this.send.call(this.env,t)}post(t){return this.send.call(this.env,t,"POST")}}return new class{constructor(t,e){this.name=t,this.http=new s(this),this.data=null,this.dataFile="box.dat",this.logs=[],this.isMute=!1,this.isNeedRewrite=!1,this.logSeparator="\n",this.startTime=(new Date).getTime(),Object.assign(this,e),this.log("",`\ud83d\udd14${this.name}, \u5f00\u59cb!`)}isNode(){return"undefined"!=typeof module&&!!module.exports}isQuanX(){return"undefined"!=typeof $task}isSurge(){return"undefined"!=typeof $httpClient&&"undefined"==typeof $loon}isLoon(){return"undefined"!=typeof $loon}toObj(t,e=null){try{return JSON.parse(t)}catch{return e}}toStr(t,e=null){try{return JSON.stringify(t)}catch{return e}}getjson(t,e){let s=e;const i=this.getdata(t);if(i)try{s=JSON.parse(this.getdata(t))}catch{}return s}setjson(t,e){try{return this.setdata(JSON.stringify(t),e)}catch{return!1}}getScript(t){return new Promise(e=>{this.get({url:t},(t,s,i)=>e(i))})}runScript(t,e){return new Promise(s=>{let i=this.getdata("@chavy_boxjs_userCfgs.httpapi");i=i?i.replace(/\n/g,"").trim():i;let r=this.getdata("@chavy_boxjs_userCfgs.httpapi_timeout");r=r?1*r:20,r=e&&e.timeout?e.timeout:r;const[o,h]=i.split("@"),a={url:`http://${h}/v1/scripting/evaluate`,body:{script_text:t,mock_type:"cron",timeout:r},headers:{"X-Key":o,Accept:"*/*"}};this.post(a,(t,e,i)=>s(i))}).catch(t=>this.logErr(t))}loaddata(){if(!this.isNode())return{};{this.fs=this.fs?this.fs:require("fs"),this.path=this.path?this.path:require("path");const t=this.path.resolve(this.dataFile),e=this.path.resolve(process.cwd(),this.dataFile),s=this.fs.existsSync(t),i=!s&&this.fs.existsSync(e);if(!s&&!i)return{};{const i=s?t:e;try{return JSON.parse(this.fs.readFileSync(i))}catch(t){return{}}}}}writedata(){if(this.isNode()){this.fs=this.fs?this.fs:require("fs"),this.path=this.path?this.path:require("path");const t=this.path.resolve(this.dataFile),e=this.path.resolve(process.cwd(),this.dataFile),s=this.fs.existsSync(t),i=!s&&this.fs.existsSync(e),r=JSON.stringify(this.data);s?this.fs.writeFileSync(t,r):i?this.fs.writeFileSync(e,r):this.fs.writeFileSync(t,r)}}lodash_get(t,e,s){const i=e.replace(/\[(\d+)\]/g,".$1").split(".");let r=t;for(const t of i)if(r=Object(r)[t],void 0===r)return s;return r}lodash_set(t,e,s){return Object(t)!==t?t:(Array.isArray(e)||(e=e.toString().match(/[^.[\]]+/g)||[]),e.slice(0,-1).reduce((t,s,i)=>Object(t[s])===t[s]?t[s]:t[s]=Math.abs(e[i+1])>>0==+e[i+1]?[]:{},t)[e[e.length-1]]=s,t)}getdata(t){let e=this.getval(t);if(/^@/.test(t)){const[,s,i]=/^@(.*?)\.(.*?)$/.exec(t),r=s?this.getval(s):"";if(r)try{const t=JSON.parse(r);e=t?this.lodash_get(t,i,""):e}catch(t){e=""}}return e}setdata(t,e){let s=!1;if(/^@/.test(e)){const[,i,r]=/^@(.*?)\.(.*?)$/.exec(e),o=this.getval(i),h=i?"null"===o?null:o||"{}":"{}";try{const e=JSON.parse(h);this.lodash_set(e,r,t),s=this.setval(JSON.stringify(e),i)}catch(e){const o={};this.lodash_set(o,r,t),s=this.setval(JSON.stringify(o),i)}}else s=this.setval(t,e);return s}getval(t){return this.isSurge()||this.isLoon()?$persistentStore.read(t):this.isQuanX()?$prefs.valueForKey(t):this.isNode()?(this.data=this.loaddata(),this.data[t]):this.data&&this.data[t]||null}setval(t,e){return this.isSurge()||this.isLoon()?$persistentStore.write(t,e):this.isQuanX()?$prefs.setValueForKey(t,e):this.isNode()?(this.data=this.loaddata(),this.data[e]=t,this.writedata(),!0):this.data&&this.data[e]||null}initGotEnv(t){this.got=this.got?this.got:require("got"),this.cktough=this.cktough?this.cktough:require("tough-cookie"),this.ckjar=this.ckjar?this.ckjar:new this.cktough.CookieJar,t&&(t.headers=t.headers?t.headers:{},void 0===t.headers.Cookie&&void 0===t.cookieJar&&(t.cookieJar=this.ckjar))}get(t,e=(()=>{})){t.headers&&(delete t.headers["Content-Type"],delete t.headers["Content-Length"]),this.isSurge()||this.isLoon()?(this.isSurge()&&this.isNeedRewrite&&(t.headers=t.headers||{},Object.assign(t.headers,{"X-Surge-Skip-Scripting":!1})),$httpClient.get(t,(t,s,i)=>{!t&&s&&(s.body=i,s.statusCode=s.status),e(t,s,i)})):this.isQuanX()?(this.isNeedRewrite&&(t.opts=t.opts||{},Object.assign(t.opts,{hints:!1})),$task.fetch(t).then(t=>{const{statusCode:s,statusCode:i,headers:r,body:o}=t;e(null,{status:s,statusCode:i,headers:r,body:o},o)},t=>e(t))):this.isNode()&&(this.initGotEnv(t),this.got(t).on("redirect",(t,e)=>{try{if(t.headers["set-cookie"]){const s=t.headers["set-cookie"].map(this.cktough.Cookie.parse).toString();this.ckjar.setCookieSync(s,null),e.cookieJar=this.ckjar}}catch(t){this.logErr(t)}}).then(t=>{const{statusCode:s,statusCode:i,headers:r,body:o}=t;e(null,{status:s,statusCode:i,headers:r,body:o},o)},t=>{const{message:s,response:i}=t;e(s,i,i&&i.body)}))}post(t,e=(()=>{})){if(t.body&&t.headers&&!t.headers["Content-Type"]&&(t.headers["Content-Type"]="application/x-www-form-urlencoded"),t.headers&&delete t.headers["Content-Length"],this.isSurge()||this.isLoon())this.isSurge()&&this.isNeedRewrite&&(t.headers=t.headers||{},Object.assign(t.headers,{"X-Surge-Skip-Scripting":!1})),$httpClient.post(t,(t,s,i)=>{!t&&s&&(s.body=i,s.statusCode=s.status),e(t,s,i)});else if(this.isQuanX())t.method="POST",this.isNeedRewrite&&(t.opts=t.opts||{},Object.assign(t.opts,{hints:!1})),$task.fetch(t).then(t=>{const{statusCode:s,statusCode:i,headers:r,body:o}=t;e(null,{status:s,statusCode:i,headers:r,body:o},o)},t=>e(t));else if(this.isNode()){this.initGotEnv(t);const{url:s,...i}=t;this.got.post(s,i).then(t=>{const{statusCode:s,statusCode:i,headers:r,body:o}=t;e(null,{status:s,statusCode:i,headers:r,body:o},o)},t=>{const{message:s,response:i}=t;e(s,i,i&&i.body)})}}time(t){let e={"M+":(new Date).getMonth()+1,"d+":(new Date).getDate(),"H+":(new Date).getHours(),"m+":(new Date).getMinutes(),"s+":(new Date).getSeconds(),"q+":Math.floor(((new Date).getMonth()+3)/3),S:(new Date).getMilliseconds()};/(y+)/.test(t)&&(t=t.replace(RegExp.$1,((new Date).getFullYear()+"").substr(4-RegExp.$1.length)));for(let s in e)new RegExp("("+s+")").test(t)&&(t=t.replace(RegExp.$1,1==RegExp.$1.length?e[s]:("00"+e[s]).substr((""+e[s]).length)));return t}msg(e=t,s="",i="",r){const o=t=>{if(!t)return t;if("string"==typeof t)return this.isLoon()?t:this.isQuanX()?{"open-url":t}:this.isSurge()?{url:t}:void 0;if("object"==typeof t){if(this.isLoon()){let e=t.openUrl||t.url||t["open-url"],s=t.mediaUrl||t["media-url"];return{openUrl:e,mediaUrl:s}}if(this.isQuanX()){let e=t["open-url"]||t.url||t.openUrl,s=t["media-url"]||t.mediaUrl;return{"open-url":e,"media-url":s}}if(this.isSurge()){let e=t.url||t.openUrl||t["open-url"];return{url:e}}}};this.isMute||(this.isSurge()||this.isLoon()?$notification.post(e,s,i,o(r)):this.isQuanX()&&$notify(e,s,i,o(r)));let h=["","==============\ud83d\udce3\u7cfb\u7edf\u901a\u77e5\ud83d\udce3=============="];h.push(e),s&&h.push(s),i&&h.push(i),console.log(h.join("\n")),this.logs=this.logs.concat(h)}log(...t){t.length>0&&(this.logs=[...this.logs,...t]),console.log(t.join(this.logSeparator))}logErr(t,e){const s=!this.isSurge()&&!this.isQuanX()&&!this.isLoon();s?this.log("",`\u2757\ufe0f${this.name}, \u9519\u8bef!`,t.stack):this.log("",`\u2757\ufe0f${this.name}, \u9519\u8bef!`,t)}wait(t){return new Promise(e=>setTimeout(e,t))}done(t={}){const e=(new Date).getTime(),s=(e-this.startTime)/1e3;this.log("",`\ud83d\udd14${this.name}, \u7ed3\u675f! \ud83d\udd5b ${s} \u79d2`),this.log(),(this.isSurge()||this.isQuanX()||this.isLoon())&&$done(t)}}(t,e)}
var date=function(format, timestamp) {
	  // http://kevin.vanzonneveld.net
	  // +   original by: Carlos R. L. Rodrigues (http://www.jsfromhell.com)
	  // +      parts by: Peter-Paul Koch (http://www.quirksmode.org/js/beat.html)
	  // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
	  // +   improved by: MeEtc (http://yass.meetcweb.com)
	  // +   improved by: Brad Touesnard
	  // +   improved by: Tim Wiel
	  // +   improved by: Bryan Elliott
	  //
	  // +   improved by: Brett Zamir (http://brett-zamir.me)
	  // +   improved by: David Randall
	  // +      input by: Brett Zamir (http://brett-zamir.me)
	  // +   bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
	  // +   improved by: Brett Zamir (http://brett-zamir.me)
	  // +   improved by: Brett Zamir (http://brett-zamir.me)
	  // +   improved by: Theriault
	  // +  derived from: gettimeofday
	  // +      input by: majak
	  // +   bugfixed by: majak
	  // +   bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
	  // +      input by: Alex
	  // +   bugfixed by: Brett Zamir (http://brett-zamir.me)
	  // +   improved by: Theriault
	  // +   improved by: Brett Zamir (http://brett-zamir.me)
	  // +   improved by: Theriault
	  // +   improved by: Thomas Beaucourt (http://www.webapp.fr)
	  // +   improved by: JT
	  // +   improved by: Theriault
	  // +   improved by: Rafał Kukawski (http://blog.kukawski.pl)
	  // +   bugfixed by: omid (http://phpjs.org/functions/380:380#comment_137122)
	  // +      input by: Martin
	  // +      input by: Alex Wilson
	  // +   bugfixed by: Chris (http://www.devotis.nl/)
	  // %        note 1: Uses global: php_js to store the default timezone
	  // %        note 2: Although the function potentially allows timezone info (see notes), it currently does not set
	  // %        note 2: per a timezone specified by date_default_timezone_set(). Implementers might use
	  // %        note 2: this.php_js.currentTimezoneOffset and this.php_js.currentTimezoneDST set by that function
	  // %        note 2: in order to adjust the dates in this function (or our other date functions!) accordingly
	  // *     example 1: date('H:m:s \\m \\i\\s \\m\\o\\n\\t\\h', 1062402400);
	  // *     returns 1: '09:09:40 m is month'
	  // *     example 2: date('F j, Y, g:i a', 1062462400);
	  // *     returns 2: 'September 2, 2003, 2:26 am'
	  // *     example 3: date('Y W o', 1062462400);
	  // *     returns 3: '2003 36 2003'
	  // *     example 4: x = date('Y m d', (new Date()).getTime()/1000);
	  // *     example 4: (x+'').length == 10 // 2009 01 09
	  // *     returns 4: true
	  // *     example 5: date('W', 1104534000);
	  // *     returns 5: '53'
	  // *     example 6: date('B t', 1104534000);
	  // *     returns 6: '999 31'
	  // *     example 7: date('W U', 1293750000.82); // 2010-12-31
	  // *     returns 7: '52 1293750000'
	  // *     example 8: date('W', 1293836400); // 2011-01-01
	  // *     returns 8: '52'
	  // *     example 9: date('W Y-m-d', 1293974054); // 2011-01-02
	  // *     returns 9: '52 2011-01-02'
	    var that = this,
	      jsdate,
	      f,
	      formatChr = /\\?([a-z])/gi,
	      formatChrCb,
	      // Keep this here (works, but for code commented-out
	      // below for file size reasons)
	      //, tal= [],
	      _pad = function (n, c) {
	        n = n.toString();
	        return n.length < c ? _pad('0' + n, c, '0') : n;
	      },
	      txt_words = ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Satur", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	  formatChrCb = function (t, s) {
	    return f[t] ? f[t]() : s;
	  };
	  f = {
	    // Day
	    d: function () { // Day of month w/leading 0; 01..31
	      return _pad(f.j(), 2);
	    },
	    D: function () { // Shorthand day name; Mon...Sun
	      return f.l().slice(0, 3);
	    },
	    j: function () { // Day of month; 1..31
	      return jsdate.getDate();
	    },
	    l: function () { // Full day name; Monday...Sunday
	      return txt_words[f.w()] + 'day';
	    },
	    N: function () { // ISO-8601 day of week; 1[Mon]..7[Sun]
	      return f.w() || 7;
	    },
	    S: function(){ // Ordinal suffix for day of month; st, nd, rd, th
	      var j = f.j()
	      i = j%10;
	      if (i <= 3 && parseInt((j%100)/10) == 1) i = 0;
	      return ['st', 'nd', 'rd'][i - 1] || 'th';
	    },
	    w: function () { // Day of week; 0[Sun]..6[Sat]
	      return jsdate.getDay();
	    },
	    z: function () { // Day of year; 0..365
	      var a = new Date(f.Y(), f.n() - 1, f.j()),
	        b = new Date(f.Y(), 0, 1);
	      return Math.round((a - b) / 864e5);
	    },

	    // Week
	    W: function () { // ISO-8601 week number
	      var a = new Date(f.Y(), f.n() - 1, f.j() - f.N() + 3),
	        b = new Date(a.getFullYear(), 0, 4);
	      return _pad(1 + Math.round((a - b) / 864e5 / 7), 2);
	    },

	    // Month
	    F: function () { // Full month name; January...December
	      return txt_words[6 + f.n()];
	    },
	    m: function () { // Month w/leading 0; 01...12
	      return _pad(f.n(), 2);
	    },
	    M: function () { // Shorthand month name; Jan...Dec
	      return f.F().slice(0, 3);
	    },
	    n: function () { // Month; 1...12
	      return jsdate.getMonth() + 1;
	    },
	    t: function () { // Days in month; 28...31
	      return (new Date(f.Y(), f.n(), 0)).getDate();
	    },

	    // Year
	    L: function () { // Is leap year?; 0 or 1
	      var j = f.Y();
	      return j % 4 === 0 & j % 100 !== 0 | j % 400 === 0;
	    },
	    o: function () { // ISO-8601 year
	      var n = f.n(),
	        W = f.W(),
	        Y = f.Y();
	      return Y + (n === 12 && W < 9 ? 1 : n === 1 && W > 9 ? -1 : 0);
	    },
	    Y: function () { // Full year; e.g. 1980...2010
	      return jsdate.getFullYear();
	    },
	    y: function () { // Last two digits of year; 00...99
	      return f.Y().toString().slice(-2);
	    },

	    // Time
	    a: function () { // am or pm
	      return jsdate.getHours() > 11 ? "pm" : "am";
	    },
	    A: function () { // AM or PM
	      return f.a().toUpperCase();
	    },
	    B: function () { // Swatch Internet time; 000..999
	      var H = jsdate.getUTCHours() * 36e2,
	        // Hours
	        i = jsdate.getUTCMinutes() * 60,
	        // Minutes
	        s = jsdate.getUTCSeconds(); // Seconds
	      return _pad(Math.floor((H + i + s + 36e2) / 86.4) % 1e3, 3);
	    },
	    g: function () { // 12-Hours; 1..12
	      return f.G() % 12 || 12;
	    },
	    G: function () { // 24-Hours; 0..23
	      return jsdate.getHours();
	    },
	    h: function () { // 12-Hours w/leading 0; 01..12
	      return _pad(f.g(), 2);
	    },
	    H: function () { // 24-Hours w/leading 0; 00..23
	      return _pad(f.G(), 2);
	    },
	    i: function () { // Minutes w/leading 0; 00..59
	      return _pad(jsdate.getMinutes(), 2);
	    },
	    s: function () { // Seconds w/leading 0; 00..59
	      return _pad(jsdate.getSeconds(), 2);
	    },
	    u: function () { // Microseconds; 000000-999000
	      return _pad(jsdate.getMilliseconds() * 1000, 6);
	    },

	    // Timezone
	    e: function () { // Timezone identifier; e.g. Atlantic/Azores, ...
	      // The following works, but requires inclusion of the very large
	      // timezone_abbreviations_list() function.
	/*              return that.date_default_timezone_get();
	*/
	      throw 'Not supported (see source code of date() for timezone on how to add support)';
	    },
	    I: function () { // DST observed?; 0 or 1
	      // Compares Jan 1 minus Jan 1 UTC to Jul 1 minus Jul 1 UTC.
	      // If they are not equal, then DST is observed.
	      var a = new Date(f.Y(), 0),
	        // Jan 1
	        c = Date.UTC(f.Y(), 0),
	        // Jan 1 UTC
	        b = new Date(f.Y(), 6),
	        // Jul 1
	        d = Date.UTC(f.Y(), 6); // Jul 1 UTC
	      return ((a - c) !== (b - d)) ? 1 : 0;
	    },
	    O: function () { // Difference to GMT in hour format; e.g. +0200
	      var tzo = jsdate.getTimezoneOffset(),
	        a = Math.abs(tzo);
	      return (tzo > 0 ? "-" : "+") + _pad(Math.floor(a / 60) * 100 + a % 60, 4);
	    },
	    P: function () { // Difference to GMT w/colon; e.g. +02:00
	      var O = f.O();
	      return (O.substr(0, 3) + ":" + O.substr(3, 2));
	    },
	    T: function () { // Timezone abbreviation; e.g. EST, MDT, ...
	      // The following works, but requires inclusion of the very
	      // large timezone_abbreviations_list() function.
	/*              var abbr = '', i = 0, os = 0, default = 0;
	      if (!tal.length) {
	        tal = that.timezone_abbreviations_list();
	      }
	      if (that.php_js && that.php_js.default_timezone) {
	        default = that.php_js.default_timezone;
	        for (abbr in tal) {
	          for (i=0; i < tal[abbr].length; i++) {
	            if (tal[abbr][i].timezone_id === default) {
	              return abbr.toUpperCase();
	            }
	          }
	        }
	      }
	      for (abbr in tal) {
	        for (i = 0; i < tal[abbr].length; i++) {
	          os = -jsdate.getTimezoneOffset() * 60;
	          if (tal[abbr][i].offset === os) {
	            return abbr.toUpperCase();
	          }
	        }
	      }
	*/
	      return 'UTC';
	    },
	    Z: function () { // Timezone offset in seconds (-43200...50400)
	      return -jsdate.getTimezoneOffset() * 60;
	    },

	    // Full Date/Time
	    c: function () { // ISO-8601 date.
	      return 'Y-m-d\\TH:i:sP'.replace(formatChr, formatChrCb);
	    },
	    r: function () { // RFC 2822
	      return 'D, d M Y H:i:s O'.replace(formatChr, formatChrCb);
	    },
	    U: function () { // Seconds since UNIX epoch
	      return jsdate / 1000 | 0;
	    }
	  };
	  this.date = function (format, timestamp) {
	    that = this;
	    jsdate = (timestamp === undefined ? new Date() : // Not provided
	      (timestamp instanceof Date) ? new Date(timestamp) : // JS Date()
	      new Date(timestamp * 1000) // UNIX timestamp (auto-convert to int)
	    );
	    return format.replace(formatChr, formatChrCb);
	  };
	  return this.date(format, timestamp);
	}
	var strtotime=function(text, now) {
  //  discuss at: http://phpjs.org/functions/strtotime/
  //     version: 1109.2016
  // original by: Caio Ariede (http://caioariede.com)
  // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  // improved by: Caio Ariede (http://caioariede.com)
  // improved by: A. Matías Quezada (http://amatiasq.com)
  // improved by: preuter
  // improved by: Brett Zamir (http://brett-zamir.me)
  // improved by: Mirko Faber
  //    input by: David
  // bugfixed by: Wagner B. Soares
  // bugfixed by: Artur Tchernychev
  //        note: Examples all have a fixed timestamp to prevent tests to fail because of variable time(zones)
  //   example 1: strtotime('+1 day', 1129633200);
  //   returns 1: 1129719600
  //   example 2: strtotime('+1 week 2 days 4 hours 2 seconds', 1129633200);
  //   returns 2: 1130425202
  //   example 3: strtotime('last month', 1129633200);
  //   returns 3: 1127041200
  //   example 4: strtotime('2009-05-04 08:30:00 GMT');
  //   returns 4: 1241425800

  var parsed, match, today, year, date, days, ranges, len, times, regex, i, fail = false;

  if (!text) {
    return fail;
  }

  // Unecessary spaces
  text = text.replace(/^\s+|\s+$/g, '')
    .replace(/\s{2,}/g, ' ')
    .replace(/[\t\r\n]/g, '')
    .toLowerCase();

  // in contrast to php, js Date.parse function interprets:
  // dates given as yyyy-mm-dd as in timezone: UTC,
  // dates with "." or "-" as MDY instead of DMY
  // dates with two-digit years differently
  // etc...etc...
  // ...therefore we manually parse lots of common date formats
  match = text.match(
    /^(\d{1,4})([\-\.\/\:])(\d{1,2})([\-\.\/\:])(\d{1,4})(?:\s(\d{1,2}):(\d{2})?:?(\d{2})?)?(?:\s([A-Z]+)?)?$/);

  if (match && match[2] === match[4]) {
    if (match[1] > 1901) {
      switch (match[2]) {
        case '-':
          { // YYYY-M-D
            if (match[3] > 12 || match[5] > 31) {
              return fail;
            }

            return new Date(match[1], parseInt(match[3], 10) - 1, match[5],
              match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
          }
        case '.':
          { // YYYY.M.D is not parsed by strtotime()
            return fail;
          }
        case '/':
          { // YYYY/M/D
            if (match[3] > 12 || match[5] > 31) {
              return fail;
            }

            return new Date(match[1], parseInt(match[3], 10) - 1, match[5],
              match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
          }
      }
    } else if (match[5] > 1901) {
      switch (match[2]) {
        case '-':
          { // D-M-YYYY
            if (match[3] > 12 || match[1] > 31) {
              return fail;
            }

            return new Date(match[5], parseInt(match[3], 10) - 1, match[1],
              match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
          }
        case '.':
          { // D.M.YYYY
            if (match[3] > 12 || match[1] > 31) {
              return fail;
            }

            return new Date(match[5], parseInt(match[3], 10) - 1, match[1],
              match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
          }
        case '/':
          { // M/D/YYYY
            if (match[1] > 12 || match[3] > 31) {
              return fail;
            }

            return new Date(match[5], parseInt(match[1], 10) - 1, match[3],
              match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
          }
      }
    } else {
      switch (match[2]) {
        case '-':
          { // YY-M-D
            if (match[3] > 12 || match[5] > 31 || (match[1] < 70 && match[1] > 38)) {
              return fail;
            }

            year = match[1] >= 0 && match[1] <= 38 ? +match[1] + 2000 : match[1];
            return new Date(year, parseInt(match[3], 10) - 1, match[5],
              match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
          }
        case '.':
          { // D.M.YY or H.MM.SS
            if (match[5] >= 70) { // D.M.YY
              if (match[3] > 12 || match[1] > 31) {
                return fail;
              }

              return new Date(match[5], parseInt(match[3], 10) - 1, match[1],
                match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
            }
            if (match[5] < 60 && !match[6]) { // H.MM.SS
              if (match[1] > 23 || match[3] > 59) {
                return fail;
              }

              today = new Date();
              return new Date(today.getFullYear(), today.getMonth(), today.getDate(),
                match[1] || 0, match[3] || 0, match[5] || 0, match[9] || 0) / 1000;
            }

            return fail; // invalid format, cannot be parsed
          }
        case '/':
          { // M/D/YY
            if (match[1] > 12 || match[3] > 31 || (match[5] < 70 && match[5] > 38)) {
              return fail;
            }

            year = match[5] >= 0 && match[5] <= 38 ? +match[5] + 2000 : match[5];
            return new Date(year, parseInt(match[1], 10) - 1, match[3],
              match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
          }
        case ':':
          { // HH:MM:SS
            if (match[1] > 23 || match[3] > 59 || match[5] > 59) {
              return fail;
            }

            today = new Date();
            return new Date(today.getFullYear(), today.getMonth(), today.getDate(),
              match[1] || 0, match[3] || 0, match[5] || 0) / 1000;
          }
      }
    }
  }

  // other formats and "now" should be parsed by Date.parse()
  if (text === 'now') {
    return now === null || isNaN(now) ? new Date()
      .getTime() / 1000 | 0 : now | 0;
  }
  if (!isNaN(parsed = Date.parse(text))) {
    return parsed / 1000 | 0;
  }

  date = now ? new Date(now * 1000) : new Date();
  days = {
    'sun': 0,
    'mon': 1,
    'tue': 2,
    'wed': 3,
    'thu': 4,
    'fri': 5,
    'sat': 6
  };
  ranges = {
    'yea': 'FullYear',
    'mon': 'Month',
    'day': 'Date',
    'hou': 'Hours',
    'min': 'Minutes',
    'sec': 'Seconds'
  };

  function lastNext(type, range, modifier) {
    var diff, day = days[range];

    if (typeof day !== 'undefined') {
      diff = day - date.getDay();

      if (diff === 0) {
        diff = 7 * modifier;
      } else if (diff > 0 && type === 'last') {
        diff -= 7;
      } else if (diff < 0 && type === 'next') {
        diff += 7;
      }

      date.setDate(date.getDate() + diff);
    }
  }

  function process(val) {
    var splt = val.split(' '), // Todo: Reconcile this with regex using \s, taking into account browser issues with split and regexes
      type = splt[0],
      range = splt[1].substring(0, 3),
      typeIsNumber = /\d+/.test(type),
      ago = splt[2] === 'ago',
      num = (type === 'last' ? -1 : 1) * (ago ? -1 : 1);

    if (typeIsNumber) {
      num *= parseInt(type, 10);
    }

    if (ranges.hasOwnProperty(range) && !splt[1].match(/^mon(day|\.)?$/i)) {
      return date['set' + ranges[range]](date['get' + ranges[range]]() + num);
    }

    if (range === 'wee') {
      return date.setDate(date.getDate() + (num * 7));
    }

    if (type === 'next' || type === 'last') {
      lastNext(type, range, num);
    } else if (!typeIsNumber) {
      return false;
    }

    return true;
  }

  times = '(years?|months?|weeks?|days?|hours?|minutes?|min|seconds?|sec' +
    '|sunday|sun\\.?|monday|mon\\.?|tuesday|tue\\.?|wednesday|wed\\.?' +
    '|thursday|thu\\.?|friday|fri\\.?|saturday|sat\\.?)';
  regex = '([+-]?\\d+\\s' + times + '|' + '(last|next)\\s' + times + ')(\\sago)?';

  match = text.match(new RegExp(regex, 'gi'));
  if (!match) {
    return fail;
  }

  for (i = 0, len = match.length; i < len; i++) {
    if (!process(match[i])) {
      return fail;
    }
  }

  // ECMAScript 5 only
  // if (!match.every(process))
  //    return false;

  return (date.getTime() / 1000);
}